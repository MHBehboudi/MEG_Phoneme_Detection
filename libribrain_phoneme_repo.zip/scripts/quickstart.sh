
#!/usr/bin/env bash
python -u src/phoneme/train_lstm_v12_submit.py   --mode train_and_submit   --stage1_epochs 8   --stage2_epochs 6 --stage2_lr 3e-5   --multik_stage2   --batch_size 16 --precision 16-mixed   --per_sample_zscore_val_avg --per_sample_zscore_val_single   --per_sample_zscore_holdout   --tta_shifts "0,2,-2,4,-4"
