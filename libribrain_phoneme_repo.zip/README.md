
# LibriBrain Phoneme Detection (LSTM_v12)

This repo contains a starter pipeline for the **LibriBrain 2025 Phoneme Detection Competition**.

## Quickstart

```bash
conda env create -f environment.yml
conda activate libribrain_env

# Put competition data under ./libribrain_data/data/

bash scripts/quickstart.sh
```

## SLURM
```bash
sbatch scripts/slurm_train_submit.sbatch
```
